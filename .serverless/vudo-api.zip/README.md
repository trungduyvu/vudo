
**Master**: 
[![CircleCI](https://circleci.com/gh/trungduyvu/vudo/tree/master.svg?style=svg&circle-token=03a4a85f39ad44a5d0359947de19e2db1231ff28)](https://circleci.com/gh/trungduyvu/vudo/tree/master)

**Develop**: 
[![CircleCI](https://circleci.com/gh/trungduyvu/vudo/tree/develop.svg?style=svg&circle-token=03a4a85f39ad44a5d0359947de19e2db1231ff28)](https://circleci.com/gh/trungduyvu/vudo/tree/develop)